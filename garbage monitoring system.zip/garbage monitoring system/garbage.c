#include <Wire.h>
#include <LiquidCrystal_I2C.h>,; 

const String phoneNumber1 = "+917208601262"; 
const String phoneNumber2 = "+917021915329"; 

LiquidCrystal_I2C lcd(0x27, 16, 2);

const int trigPin = D6;
const int echoPin = D5;
const int threshold = 80;
  
void setup() {
  lcd.begin();
  lcd.backlight();
  Serial.begin(115200);

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  delay(1000);

  lcd.clear();
  lcd.print("Smart Dustbin");
  lcd.setCursor(0, 1);
  lcd.print("Initializing...");
  delay(2000);
}

void loop() {
  long duration, distance;
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  duration = pulseIn(echoPin, HIGH);
  distance = (duration / 2) / 29.1;

  int fillLevel = map(distance, 0, 20, 100, 0);

  lcd.clear();
  lcd.print("Fill Level: ");
  lcd.print(fillLevel);
  lcd.print("%");

  if (fillLevel >= threshold) {
    sendSMSAlert();
  }

  delay(2000);
}

void sendSMSAlert() {
  lcd.clear();
  lcd.print("Sending Alert...");

  Serial.println("AT");
  delay(1000);                  // Wait for response
  Serial.println("AT+CMGF=1");  // Set SMS mode to text
  delay(1000);                  // Wait for response

  // Send SMS to phoneNumber1
  Serial.print("AT+CMGS=\"");
  Serial.print(phoneNumber1);
  Serial.println("\"");                         // Send destination phone number
  delay(1000);                                  // Wait for response
  Serial.print("Dustbin Full! Please Empty.");  // Your message here
  Serial.write(26);                             // End SMS with Ctrl+Z
  delay(1000);                                  // Wait for response

  if (Serial.find("OK")) {
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Message Sent to 1");
  }

  // Send SMS to phoneNumber2
  Serial.print("AT+CMGS=\"");
  Serial.print(phoneNumber2);
  Serial.println("\"");                         // Send destination phone number
  delay(1000);                                  // Wait for response
  Serial.print("Dustbin Full! Please Empty.");  // Your message here
  Serial.write(26);                             // End SMS with Ctrl+Z
  delay(1000);                                  // Wait for response

  if (Serial.find("OK")) {
    lcd.clear();
    lcd.setCursor(0, 1);
    lcd.print("Message Sent to 2");
  }
  delay(5000);
}

